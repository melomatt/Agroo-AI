import React from 'react';
import './Cards.css';
import CardItem from './CardItem';

function Cards() {
  return (
    <div className='cards'>
      <h1>Discover the Benefits of Agro A I for Modern Agriculture!</h1>
      <div className='cards__container'>
        <div className='cards__wrapper'>
          <ul className='cards__items'>
            <CardItem
              src='images/crop.jpg'
              text='Use Agro A I to monitor crops and detect issues
               for increased yields and reduced costs'
              label='Crop Monitoring'
              path='/services'
            />
            <CardItem
              src='images/soil.jpg'
              text=' Analyze soil conditions with Agro A I for 
              improved crop quality and reduced environmental impact'
              label='Soil Analysis'
              path='/services'
            />
          </ul>
          <ul className='cards__items'>
            <CardItem
              src='images/climate.jpg'
              text='Predict climate patterns and weather events
               with Agro A I for increased efficiency and reduced risk of crop damage'
              label='Climate Prediction'
              path='/services'
            />
            <CardItem
              src='images/precision.jpg'
              text='Optimize farming practices and improve efficiency
               with Agro A I for increased yields and reduced costs'
              label='Precision Farming'
              path='/products'
            />
            <CardItem
              src='images/food.jpg'
              text='Improve food safety with Agro A I for increased
               consumer confidence and reduced risk of recalls'
              label='Food Safety'
              path='/sign-up'
            />
          </ul>
        </div>
      </div>
    </div>
  );
}

export default Cards;
