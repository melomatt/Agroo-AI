import React from 'react';
import '../../App.css';
import { useLocation } from 'react-router-dom';
import {getTreatments, getTreatment, getTreatmentsByClass} from '../Therapy.js';
 


export default function Therapydetails(props) {
    const location = useLocation();
    const myProp = props.location.state.value;
    console.log("the transfered prop is: ", myProp);
    const treatment = getTreatmentsByClass(myProp);
    console.log("Treatment is: ", treatment);

    return <h1 className='products'>{treatment[0].details}</h1>;
  
}
