import React from 'react';
import { useLocation } from 'react-router-dom';
import {getTreatments, getTreatment, getTreatmentsByClass} from './Therapy.js';

// const location = useLocation();


function TherapyDetail() {
    const myProp = 'Healthy';// location.state.value;
    const details = getTreatmentsByClass(myProp);
    console.log("The Details Fetched are: ", details);
    
    // const myProp = "Healthy";
    // data? console.log("The transfered prop is: ", data): console.log("Failed to transfer prop");

  return (

    <>
    <div>
        <p>
        {myProp}
        </p>
    </div>
    </>

  )
  
}
export default TherapyDetail;

