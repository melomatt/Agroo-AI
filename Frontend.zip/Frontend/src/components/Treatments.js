import React, { useState } from "react";
import ViewTreatments from "../ViewTreatments.json";


function Treatments() {
  const [showTreatments, setShowTreatments] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedDisease, setSelectedDisease] = useState(null);

  const handleViewTreatments = () => {
    setShowTreatments(true);
    setSelectedDisease(null);
  };

  const handleSearch = (event) => {
    setSearchTerm(event.target.value.toLowerCase());
    setSelectedDisease(null);
  };

  const handleClick = (disease) => {
    setSelectedDisease(disease);
  };

  const filteredData = ViewTreatments.filter((disease) =>
    disease.name.toLowerCase().includes(searchTerm)
  );

  return (
    <div>
      <h1>Plant Diseases and Treatments</h1>
      <button onClick={handleViewTreatments}>View Treatments</button>
      {showTreatments && (
        <div>
          <h2>Select a Disease:</h2>
          <div>
            <input
              type="text"
              placeholder="Search for a disease..."
              value={searchTerm}
              onChange={handleSearch}
            />
            {filteredData.map((disease) => (
              <button key={disease.id} onClick={() => handleClick(disease)}>
                {disease.name}
              </button>
            ))}
          </div>
          {selectedDisease ? (
            <div>
              <h3>{selectedDisease.name}</h3>
              <p>{selectedDisease.treatment}</p>
            </div>
          ) : (
            <div>
              <p>Select a disease to view its treatment.</p>
            </div>
          )}
        </div>
      )}
      <div>
        <h2>Diseases and Treatments:</h2>
        <ul>
          {ViewTreatments.map((disease) => (
            <li key={disease.id}>
              <strong>{disease.name}</strong>: {disease.treatment}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default Treatments;
