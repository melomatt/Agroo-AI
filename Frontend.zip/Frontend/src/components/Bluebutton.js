import React from 'react';

import { useHistory } from 'react-router-dom';

const BlueButton = (props) => {
  const history = useHistory();

  const handleClick = () => {
    history.push({
      pathname: '/Therapydetails',
      state: { value: 'Healthy' }
    });
  };

  return (
    <div>
      <button style={{background: 'green', borderRadius:'12px',cursor:'pointer',fontSize:'13px',  boxShadow: '2px 2px 5px rgba(0,0,0,0.3)', color: 'white'}} onClick={handleClick}> See More Details</button>
    </div>
  );
}

export default BlueButton;